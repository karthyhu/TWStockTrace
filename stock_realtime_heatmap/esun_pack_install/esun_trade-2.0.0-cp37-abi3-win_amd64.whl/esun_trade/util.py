from os import getenv
from getpass import getpass
from keyring import get_password, set_password, set_keyring, delete_password
from keyrings.cryptfile.cryptfile import CryptFileKeyring
from hashlib import md5

TRADE_SDK_ACCOUNT_KEY = "esun_trade_sdk:account"
TRADE_SDK_CERT_KEY = "esun_trade_sdk:cert"

def setup_keyring(user_account):
    backend = getenv("PYTHON_KEYRING_BACKEND")
    if backend == "keyrings.cryptfile.cryptfile.CryptFileKeyring" or is_notebook():
        kr = CryptFileKeyring()
        kr.keyring_key = getenv("KEYRING_CRYPTFILE_PASSWORD") or hash_value(user_account)
        set_keyring(kr)


def hash_value(val):
    # hashlib.md5("whatever your string is".encode('utf-8')).hexdigest()
    return md5(val.encode('utf-8')).hexdigest()


def ft_get_password(key, user_account):
    return get_password(key, user_account)


def ft_check_password(user_account):
    if not get_password(TRADE_SDK_ACCOUNT_KEY, user_account):
        set_password(
            TRADE_SDK_ACCOUNT_KEY,
            user_account,
            getpass("Enter esun account password:\n"))

    if not get_password(TRADE_SDK_CERT_KEY, user_account):
        set_password(
            TRADE_SDK_CERT_KEY,
            user_account,
            getpass("Enter cert password:\n"))


def get_validated_password(prompt):
    """Get password from user with validation"""
    while True:
        password = getpass(prompt)
        if password and len(password) >= 1:
            return password
        print("Password cannot be empty. Please try again.")


def ft_set_password(user_account):
    set_password(
        TRADE_SDK_ACCOUNT_KEY,
        user_account,
        get_validated_password("Enter esun account password:\n"))
    set_password(
        TRADE_SDK_CERT_KEY,
        user_account,
        get_validated_password("Enter cert password:\n"))


# from https://stackoverflow.com/a/39662359
def is_notebook():
    try:
        shell = get_ipython().__class__.__name__
        if shell == 'ZMQInteractiveShell':
            return True  # Jupyter notebook or qtconsole
        elif shell == 'TerminalInteractiveShell':
            return False  # Terminal running IPython
        else:
            return False  # Other type (?)
    except NameError:
        return False  # Probably standard Python interpreter


def load_credentials(user_account):
    """
    Load credentials from keyring or prompt user if not available
    Similar to the TypeScript implementation's approach
    """
    # Get existing passwords from keyring
    account_password = get_password(TRADE_SDK_ACCOUNT_KEY, user_account)
    cert_password = get_password(TRADE_SDK_CERT_KEY, user_account)

    # Prompt for missing passwords
    if not account_password:
        new_password = getpass("Enter esun account password: ")
        set_password(TRADE_SDK_ACCOUNT_KEY, user_account, new_password)
        account_password = new_password

    if not cert_password:
        new_cert_password = getpass("Enter cert password: ")
        set_password(TRADE_SDK_CERT_KEY, user_account, new_cert_password)
        cert_password = new_cert_password

    return {
        "account_password": account_password,
        "cert_password": cert_password
    }


def remove_credentials(user_account):
    """
    Remove all stored credentials for a user account
    Equivalent to the TypeScript removeCredentials function
    """
    # Delete both passwords from the keyring
    delete_password(TRADE_SDK_ACCOUNT_KEY, user_account)
    delete_password(TRADE_SDK_CERT_KEY, user_account)
